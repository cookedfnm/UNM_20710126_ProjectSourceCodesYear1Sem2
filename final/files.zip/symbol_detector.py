"""
Symbol detection process – colour + contour shape classifier.

Instead of grayscale template matching (which confuses the ground with
solid shapes), this detector:
  1. Segments the foreground blob by dominant colour in the upper frame ROI
  2. Extracts shape features: vertex count, circularity, solidity, aspect ratio
  3. Classifies using a decision tree on (colour_group, shape_features)

Runs at ~8 Hz on frames from shared memory.
"""

import os
import time
import numpy as np
import cv2
from shared_state import open_frame_buffer

DETECT_HZ = 8
MIN_BLOB_AREA = 1500        # minimum pixels to consider a detection
CONFIRM_FRAMES = 2          # need N consecutive same-ID frames to commit
APPROX_EPS = 0.03           # contour approximation epsilon factor

# ── Symbol index (same order as before for compatibility) ──
SYMBOL_NAMES = [
    "3_4circle",           # 0
    "blue_arrow_right",    # 1
    "circular_segment",    # 2
    "diamond",             # 3
    "fingerprint",         # 4
    "green_arrow_up",      # 5
    "octagon",             # 6
    "orange_arrow_left",   # 7
    "plus",                # 8
    "press_button",        # 9
    "qr_code",             # 10
    "recycle",             # 11
    "red_arrow_down",      # 12
    "star",                # 13
    "trapezoid",           # 14
    "warning",             # 15
]

# ── HSV colour ranges for each colour group ──
# Format: (low_H, low_S, low_V, high_H, high_S, high_V)
# These are tuned to the template images; you may need to adjust for
# lighting on your Pi.
COLOUR_RANGES = {
    "blue":        (100, 120, 80,  130, 255, 255),
    "purple":      (130, 100, 60,  165, 255, 200),
    "red_orange":  (0,   140, 120, 20,  255, 255),
    "yellow":      (20,  150, 180, 35,  255, 255),
    "green":       (40,  80,  60,  85,  255, 200),
    "dark_green":  (60,  120, 60,  90,  255, 180),
    "teal":        (85,  150, 80,  100, 255, 200),
    "dark_blue":   (100, 130, 50,  125, 255, 160),
}

KERNEL_SMALL = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
KERNEL_MED = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))


def _get_colour_group(hsv_roi):
    """
    Try each colour range. Return (group_name, mask, area) for the
    largest match, or None if nothing big enough.
    """
    best = None
    for group, (lh, ls, lv, hh, hs, hv) in COLOUR_RANGES.items():
        lo = np.array([lh, ls, lv], np.uint8)
        hi = np.array([hh, hs, hv], np.uint8)
        mask = cv2.inRange(hsv_roi, lo, hi)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, KERNEL_MED)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, KERNEL_SMALL)
        area = cv2.countNonZero(mask)
        if area >= MIN_BLOB_AREA and (best is None or area > best[2]):
            best = (group, mask, area)
    return best


def _shape_features(mask):
    """
    Extract shape features from the largest contour in a binary mask.
    Returns dict or None.
    """
    cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not cnts:
        return None
    c = max(cnts, key=cv2.contourArea)
    area = cv2.contourArea(c)
    if area < MIN_BLOB_AREA:
        return None

    peri = cv2.arcLength(c, True)
    approx = cv2.approxPolyDP(c, APPROX_EPS * peri, True)
    circ = (4.0 * np.pi * area) / (peri * peri) if peri > 0 else 0
    hull = cv2.convexHull(c)
    hull_area = cv2.contourArea(hull)
    solidity = area / hull_area if hull_area > 0 else 0
    x, y, w, h = cv2.boundingRect(c)
    aspect = w / float(h) if h > 0 else 1.0
    # extent = fraction of bounding rect filled
    extent = area / (w * h) if w * h > 0 else 0

    # Count holes (internal contours)
    cnts_all, hier = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    holes = 0
    if hier is not None:
        for i, h_ in enumerate(hier[0]):
            if h_[3] >= 0:  # has parent = is a hole
                holes += 1

    return {
        "vertices": len(approx),
        "circularity": circ,
        "solidity": solidity,
        "aspect": aspect,
        "extent": extent,
        "holes": holes,
        "area": area,
    }


def _classify(colour_group, feat):
    """
    Decision tree: given colour group and shape features, return symbol index.
    Returns (symbol_id, confidence) or (-1, 0.0).

    Confidence is a rough estimate (0.5–1.0) based on how cleanly the
    features match expected values.
    """
    v = feat["vertices"]
    circ = feat["circularity"]
    solid = feat["solidity"]
    aspect = feat["aspect"]
    extent = feat["extent"]
    holes = feat["holes"]

    # ── BLUE group: 3/4 circle vs blue arrow right vs qr_code ──
    if colour_group == "blue":
        # 3/4 circle: high circularity, missing wedge (solidity ~0.82)
        # blue arrow: low circularity, arrow shape (solidity ~0.63)
        if solid < 0.72:
            return 1, 0.75   # blue_arrow_right
        else:
            return 0, 0.75   # 3_4circle

    if colour_group == "dark_blue":
        # QR code: very blocky, near-square, high extent
        return 10, 0.80      # qr_code

    # ── PURPLE group: diamond vs fingerprint vs trapezoid ──
    if colour_group == "purple":
        # fingerprint: very low solidity (~0.37), lots of gaps
        if solid < 0.55:
            return 4, 0.85   # fingerprint
        # diamond: 4 vertices, rotated square (aspect ~1.0)
        # trapezoid: 4 vertices, wider at bottom (aspect < 1.0, more squat)
        if v <= 5:
            if aspect > 0.85:
                return 3, 0.75   # diamond (roughly square when rotated)
            else:
                return 14, 0.75  # trapezoid (wider than tall)
        # More vertices = could be noisy contour of either
        if aspect > 0.85:
            return 3, 0.60
        return 14, 0.60

    # ── RED / ORANGE group ──
    if colour_group == "red_orange":
        # circular_segment (red, H~60 in template but can shift): circ ~0.74, solid ~0.99
        # orange_arrow_left: arrow, solid ~0.64
        # plus: cross shape, solid ~0.86, 12 vertices
        # red_arrow_down: arrow, solid ~0.64
        if solid < 0.72:
            # Arrow shape – distinguish by aspect ratio
            if aspect > 1.2:
                return 7, 0.75   # orange_arrow_left (wider than tall)
            else:
                return 12, 0.75  # red_arrow_down (taller than wide)
        elif v >= 10 and solid < 0.90:
            return 8, 0.80       # plus (cross shape, many vertices)
        elif circ > 0.65:
            return 2, 0.75       # circular_segment
        else:
            return 8, 0.65       # plus fallback

    # ── YELLOW group: star vs warning ──
    if colour_group == "yellow":
        # star: low solidity (~0.48), pointy
        # warning: high solidity (~1.0), filled rectangle with symbol
        if solid < 0.65:
            return 13, 0.85  # star
        else:
            return 15, 0.80  # warning

    # ── GREEN group: green_arrow_up vs recycle ──
    if colour_group == "green":
        # recycle: low solidity (~0.69), three arrows with gaps
        # green_arrow_up: arrow (solidity ~0.63)
        # Recycle has more holes/complexity
        if holes >= 2 or (solid < 0.72 and v >= 8):
            return 11, 0.75  # recycle
        else:
            return 5, 0.75   # green_arrow_up

    # ── DARK GREEN: press_button ──
    if colour_group == "dark_green":
        return 9, 0.80       # press_button

    # ── TEAL: octagon ──
    if colour_group == "teal":
        return 6, 0.85       # octagon

    return -1, 0.0


def symbol_detector_process(
    frame_seq, frame_lock, quit_flag, symbol_id, symbol_conf, template_dir,
):
    shm, frame_buf = open_frame_buffer(writable=False)

    period = 1.0 / DETECT_HZ
    last_seq = 0
    confirm_id = -1
    confirm_count = 0
    print("[SYMBOL] started (colour+shape classifier)")

    try:
        while not quit_flag.value:
            seq = frame_seq.value
            if seq == last_seq:
                time.sleep(0.005)
                continue
            last_seq = seq

            with frame_lock:
                frame = frame_buf.copy()

            # Use upper 40% of frame (symbols/signs are above the line)
            h = frame.shape[0]
            roi = frame[: int(h * 0.4), :]

            # Blur to reduce noise
            blurred = cv2.GaussianBlur(roi, (5, 5), 0)
            hsv = cv2.cvtColor(blurred, cv2.COLOR_BGR2HSV)

            result = _get_colour_group(hsv)
            det_id = -1
            det_conf = 0.0

            if result is not None:
                colour_group, mask, area = result
                feat = _shape_features(mask)
                if feat is not None:
                    det_id, det_conf = _classify(colour_group, feat)

            # Require N consecutive matching frames to commit
            if det_id >= 0:
                if det_id == confirm_id:
                    confirm_count += 1
                else:
                    confirm_id = det_id
                    confirm_count = 1

                if confirm_count >= CONFIRM_FRAMES:
                    symbol_id.value = det_id
                    symbol_conf.value = det_conf
            else:
                confirm_count = 0
                confirm_id = -1
                symbol_id.value = -1
                symbol_conf.value = 0.0

            time.sleep(period)

    except KeyboardInterrupt:
        pass
    finally:
        shm.close()
        print("[SYMBOL] stopped")
