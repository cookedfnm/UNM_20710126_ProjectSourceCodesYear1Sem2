"""
Line-following process with PID control.
Supports four track modes:
  1 = black line (with colour junction state machine)
  2 = red line (HSV, falls back to black)
  3 = yellow line (HSV, falls back to black)
  4 = red + yellow (follows whichever is visible, falls back to black)

Reads frames from shared memory, writes motor commands to shared state.
"""

import time
import numpy as np
import cv2
from shared_state import (
    FRAME_W, FRAME_H, open_frame_buffer,
    MODE_SEARCH, MODE_BLACK, MODE_RED, MODE_YELLOW,
    MODE_LOOK_RED, MODE_LOOK_YELLOW,
    TRACK_BLACK, TRACK_RED, TRACK_YELLOW, TRACK_RED_YELLOW,
)

# ── HSV ranges (tune these on your Pi under actual lighting) ──
RED_LO1 = np.array([0,   140, 100], np.uint8)
RED_HI1 = np.array([10,  255, 255], np.uint8)
RED_LO2 = np.array([170, 140, 100], np.uint8)
RED_HI2 = np.array([180, 255, 255], np.uint8)

YEL_LO = np.array([18, 100, 100], np.uint8)
YEL_HI = np.array([40, 255, 255], np.uint8)

BLACK_THRESH = 80

# ── Area thresholds ──
MIN_COLOUR = 400
MIN_BLACK = 800
MIN_LOOKAHEAD = 200

# ── PID tuning ──
BASE_SPEED = 0.30
COLOUR_SPEED = 0.25
SEARCH_TURN = 0.35

KP = 0.10
KI = 0.0001
KD = 0.10
I_CLAMP = 1.0
D_FILTER = 0.7
DEADBAND = 0.03

# ── ROI geometry ──
ROI_MAIN_TOP = FRAME_H // 3          # bottom 2/3 of frame
ROI_LOOK_TOP = FRAME_H // 4          # lookahead band
ROI_LOOK_BOT = FRAME_H // 3
FRAME_CX = FRAME_W // 2

KERNEL = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))


def _largest_contour(mask, min_area):
    cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not cnts:
        return None, 0
    c = max(cnts, key=cv2.contourArea)
    a = cv2.contourArea(c)
    return (c, a) if a >= min_area else (None, 0)


def _red_mask(hsv):
    """Red wraps around hue 0/180, so combine two ranges."""
    m1 = cv2.inRange(hsv, RED_LO1, RED_HI1)
    m2 = cv2.inRange(hsv, RED_LO2, RED_HI2)
    return cv2.morphologyEx(m1 | m2, cv2.MORPH_OPEN, KERNEL)


def _yellow_mask(hsv):
    return cv2.morphologyEx(cv2.inRange(hsv, YEL_LO, YEL_HI), cv2.MORPH_OPEN, KERNEL)


def _black_mask(gray):
    return cv2.threshold(gray, BLACK_THRESH, 255, cv2.THRESH_BINARY_INV)[1]


def _centroid_error(contour):
    """Return normalised error in [-1, 1]. Positive = line is to the right."""
    M = cv2.moments(contour)
    if M["m00"] > 0:
        cx = int(M["m10"] / M["m00"])
    else:
        x, _, w, _ = cv2.boundingRect(contour)
        cx = x + w // 2
    return (cx - FRAME_CX) / float(FRAME_CX)


def _clamp(v, lo, hi):
    return max(lo, min(hi, v))


def _find_colour(hsv, track, min_area):
    """
    Given the current track mode, try to find the target colour contour.
    Returns (mode_int, contour, area) or (None, None, 0).
    """
    if track == TRACK_RED:
        mr = _red_mask(hsv)
        c, a = _largest_contour(mr, min_area)
        return (MODE_RED, c, a) if c is not None else (None, None, 0)

    if track == TRACK_YELLOW:
        my = _yellow_mask(hsv)
        c, a = _largest_contour(my, min_area)
        return (MODE_YELLOW, c, a) if c is not None else (None, None, 0)

    if track == TRACK_RED_YELLOW:
        mr = _red_mask(hsv)
        my = _yellow_mask(hsv)
        cr, ar = _largest_contour(mr, min_area)
        cy, ay = _largest_contour(my, min_area)
        if cr is None and cy is None:
            return (None, None, 0)
        if ar >= ay:
            return (MODE_RED, cr, ar)
        return (MODE_YELLOW, cy, ay)

    return (None, None, 0)


def line_follower_process(
    frame_seq, frame_lock, running, quit_flag,
    motor_left, motor_right, line_found, line_error, line_mode,
    track_mode,
):
    shm, frame_buf = open_frame_buffer(writable=False)
    print("[LINE] started")

    # PID state
    integral = 0.0
    prev_err = 0.0
    prev_deriv = 0.0
    first_tick = True
    last_seq = 0
    t_prev = time.perf_counter()

    try:
        while not quit_flag.value:
            seq = frame_seq.value
            if seq == last_seq:
                time.sleep(0.001)
                continue
            last_seq = seq

            with frame_lock:
                frame = frame_buf.copy()

            if not running.value:
                motor_left.value = 0.0
                motor_right.value = 0.0
                time.sleep(0.01)
                continue

            now = time.perf_counter()
            dt = max(now - t_prev, 1e-3)
            t_prev = now

            track = track_mode.value

            # ── Prepare ROIs ──
            roi_main = frame[ROI_MAIN_TOP:, :]
            blurred = cv2.GaussianBlur(roi_main, (7, 7), 0)
            hsv_main = cv2.cvtColor(blurred, cv2.COLOR_BGR2HSV)
            gray_main = cv2.cvtColor(blurred, cv2.COLOR_BGR2GRAY)

            # ── Detection depends on track mode ──
            det_mode = MODE_SEARCH
            found = False
            err = 0.0

            if track == TRACK_BLACK:
                # ── Black line mode with colour junction awareness ──
                # Priority: colour in main > colour in lookahead > black
                cm, cc, _ = _find_colour_any(hsv_main, MIN_COLOUR)
                if cm is not None:
                    det_mode = cm
                    err = _centroid_error(cc)
                    found = True
                else:
                    roi_look = frame[ROI_LOOK_TOP:ROI_LOOK_BOT, :]
                    hsv_look = cv2.cvtColor(
                        cv2.GaussianBlur(roi_look, (5, 5), 0), cv2.COLOR_BGR2HSV
                    )
                    lm, lc, _ = _find_colour_any(hsv_look, MIN_LOOKAHEAD)
                    if lm is not None:
                        det_mode = (
                            MODE_LOOK_RED if lm == MODE_RED else MODE_LOOK_YELLOW
                        )
                        err = _centroid_error(lc)
                        found = True
                    else:
                        bm = _black_mask(gray_main)
                        bc, _ = _largest_contour(bm, MIN_BLACK)
                        if bc is not None:
                            det_mode = MODE_BLACK
                            err = _centroid_error(bc)
                            found = True

            else:
                # ── Colour-tracking modes (red / yellow / red+yellow) ──
                # Primary: target colour.  Fallback: black line.
                cm, cc, _ = _find_colour(hsv_main, track, MIN_COLOUR)
                if cm is not None:
                    det_mode = cm
                    err = _centroid_error(cc)
                    found = True
                else:
                    # Fallback to black so the robot doesn't just stop
                    bm = _black_mask(gray_main)
                    bc, _ = _largest_contour(bm, MIN_BLACK)
                    if bc is not None:
                        det_mode = MODE_BLACK
                        err = _centroid_error(bc)
                        found = True

            # ── Speed selection ──
            if det_mode in (MODE_RED, MODE_YELLOW, MODE_LOOK_RED, MODE_LOOK_YELLOW):
                speed = COLOUR_SPEED
            else:
                speed = BASE_SPEED

            # ── PID ──
            if found:
                smoothed = 0.7 * prev_err + 0.3 * err
                if abs(smoothed) < DEADBAND:
                    smoothed = 0.0
                integral = _clamp(integral + smoothed * dt, -I_CLAMP, I_CLAMP)
                raw_d = 0.0 if first_tick else (smoothed - prev_err) / dt
                deriv = D_FILTER * prev_deriv + (1 - D_FILTER) * raw_d
                pid = KP * smoothed + KI * integral + KD * deriv
                prev_err = smoothed
                prev_deriv = deriv
                first_tick = False
            else:
                # Lost — gentle search turn in the direction we last saw the line
                pid = (1 if prev_err >= 0 else -1) * SEARCH_TURN
                integral *= 0.8
                prev_deriv = 0.0

            left = _clamp(speed - pid, -1.0, 1.0)
            right = _clamp(speed + pid, -1.0, 1.0)

            motor_left.value = left
            motor_right.value = right
            line_found.value = found
            line_error.value = err
            line_mode.value = det_mode

    except KeyboardInterrupt:
        pass
    finally:
        motor_left.value = 0.0
        motor_right.value = 0.0
        shm.close()
        print("[LINE] stopped")


def _find_colour_any(hsv, min_area):
    """Detect any colour (red or yellow) — used in black-line mode for junction awareness."""
    mr = _red_mask(hsv)
    my = _yellow_mask(hsv)
    cr, ar = _largest_contour(mr, min_area)
    cy, ay = _largest_contour(my, min_area)
    if cr is None and cy is None:
        return None, None, 0
    if ar >= ay:
        return MODE_RED, cr, ar
    return MODE_YELLOW, cy, ay
