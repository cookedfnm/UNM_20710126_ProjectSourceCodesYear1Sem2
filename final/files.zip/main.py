#!/usr/bin/env python3
"""
Main orchestrator for the line-following robot.

Processes:
  1. Camera   — captures frames into shared memory
  2. Line     — PID line following, writes motor commands
  3. Motor    — reads motor commands, drives L298N
  4. Symbol   — colour+shape detection at ~8 Hz

Display runs on the main thread (CV2 windows need the main thread).

Keyboard (CV2 window focused):
  SPACE  = toggle running / paused
  1      = track black line (default)
  2      = track red line
  3      = track yellow line
  4      = track red + yellow
  Q/ESC  = quit
"""

import multiprocessing as mp
import signal
import os
import time
import numpy as np
import cv2

from shared_state import (
    create_shared_state, open_frame_buffer,
    FRAME_W, FRAME_H,
    MODE_NAMES, TRACK_NAMES,
    TRACK_BLACK, TRACK_RED, TRACK_YELLOW, TRACK_RED_YELLOW,
)
from feed import camera_process
from line_follower import line_follower_process
from movement import motor_process
from symbol_detector import symbol_detector_process, SYMBOL_NAMES

TEMPLATE_DIR = os.path.expanduser("~/pw3/final/templates")

# Display colours (BGR)
COL_GREEN = (0, 255, 0)
COL_RED = (0, 0, 255)
COL_YELLOW = (0, 255, 255)
COL_WHITE = (255, 255, 255)
COL_GREY = (120, 120, 120)

# ROI lines for the overlay (match line_follower.py)
ROI_MAIN_TOP = FRAME_H // 3
ROI_LOOK_TOP = FRAME_H // 4
ROI_LOOK_BOT = FRAME_H // 3


def main():
    mp.set_start_method("spawn", force=True)

    state = create_shared_state()
    shm_obj = state["shm"]

    procs = []

    # 1. Camera
    p_cam = mp.Process(
        target=camera_process,
        args=(state["frame_seq"], state["frame_lock"], state["quit_flag"]),
        daemon=True, name="camera",
    )
    procs.append(p_cam)

    # 2. Line follower (now receives track_mode)
    p_line = mp.Process(
        target=line_follower_process,
        args=(
            state["frame_seq"], state["frame_lock"],
            state["running"], state["quit_flag"],
            state["motor_left"], state["motor_right"],
            state["line_found"], state["line_error"], state["line_mode"],
            state["track_mode"],
        ),
        daemon=True, name="line",
    )
    procs.append(p_line)

    # 3. Motor
    p_motor = mp.Process(
        target=motor_process,
        args=(state["motor_left"], state["motor_right"], state["quit_flag"]),
        daemon=True, name="motor",
    )
    procs.append(p_motor)

    # 4. Symbol detector
    p_sym = mp.Process(
        target=symbol_detector_process,
        args=(
            state["frame_seq"], state["frame_lock"], state["quit_flag"],
            state["symbol_id"], state["symbol_conf"], TEMPLATE_DIR,
        ),
        daemon=True, name="symbol",
    )
    procs.append(p_sym)

    for p in procs:
        p.start()

    # ── Attach to shared frame for display ──
    shm_disp, frame_buf = open_frame_buffer(writable=False)
    last_seq = 0

    def shutdown():
        state["quit_flag"].value = True
        state["motor_left"].value = 0.0
        state["motor_right"].value = 0.0
        time.sleep(0.3)
        for p in procs:
            p.join(timeout=2.0)
            if p.is_alive():
                p.terminate()
        shm_disp.close()
        shm_obj.close()
        shm_obj.unlink()
        cv2.destroyAllWindows()
        print("Shutdown complete.")

    signal.signal(signal.SIGINT, lambda *_: None)

    print("=" * 50)
    print("  ROBOT READY — display window opening")
    print("  SPACE=start/pause  1-4=track mode  Q=quit")
    print("=" * 50)

    try:
        while not state["quit_flag"].value:
            # Grab latest frame
            seq = state["frame_seq"].value
            if seq != last_seq:
                last_seq = seq
                with state["frame_lock"]:
                    display = frame_buf.copy()
            else:
                # No new frame yet — short sleep to avoid busy-wait
                time.sleep(0.005)
                continue

            # ── Draw overlays ──
            is_running = state["running"].value
            track = state["track_mode"].value
            mode = state["line_mode"].value
            found = state["line_found"].value
            err = state["line_error"].value
            ml = state["motor_left"].value
            mr = state["motor_right"].value
            sid = state["symbol_id"].value
            sconf = state["symbol_conf"].value

            # ROI guide lines
            cv2.line(display, (0, ROI_MAIN_TOP), (FRAME_W, ROI_MAIN_TOP), COL_GREY, 1)
            cv2.line(display, (0, ROI_LOOK_TOP), (FRAME_W, ROI_LOOK_TOP), COL_GREY, 1)
            cv2.line(display, (0, ROI_LOOK_BOT), (FRAME_W, ROI_LOOK_BOT), COL_GREY, 1)

            # Centre crosshair
            cx = FRAME_W // 2
            cy_dot = (ROI_MAIN_TOP + FRAME_H) // 2
            cv2.drawMarker(display, (cx, cy_dot), COL_GREY, cv2.MARKER_CROSS, 20, 1)

            # Error dot (where the line is)
            if found:
                ex = int(cx + err * cx)
                cv2.circle(display, (ex, cy_dot), 8, COL_GREEN, -1)

            # Status bar (top-left)
            status = "RUN" if is_running else "PAUSED"
            status_col = COL_GREEN if is_running else COL_RED
            track_name = TRACK_NAMES.get(track, "?")
            mode_name = MODE_NAMES.get(mode, "?")
            sname = SYMBOL_NAMES[sid] if 0 <= sid < len(SYMBOL_NAMES) else "---"

            y = 20
            cv2.putText(display, f"{status}", (10, y),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, status_col, 2)
            y += 25
            cv2.putText(display, f"Track: {track_name} ({track})", (10, y),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, COL_WHITE, 1)
            y += 22
            cv2.putText(display, f"Seeing: {mode_name}", (10, y),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, COL_WHITE, 1)
            y += 22
            cv2.putText(display, f"Symbol: {sname} ({sconf:.2f})", (10, y),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, COL_YELLOW, 1)
            y += 22
            cv2.putText(display, f"Motors: L={ml:+.2f} R={mr:+.2f}", (10, y),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, COL_WHITE, 1)

            cv2.imshow("Robot", display)

            # ── Handle keys ──
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q') or key == 27:  # Q or ESC
                print("Quit requested.")
                break
            elif key == ord(' '):
                state["running"].value = not state["running"].value
                r = state["running"].value
                print(f"{'RUNNING' if r else 'PAUSED'}")
            elif key == ord('1'):
                state["track_mode"].value = TRACK_BLACK
                print("Track mode: BLACK")
            elif key == ord('2'):
                state["track_mode"].value = TRACK_RED
                print("Track mode: RED")
            elif key == ord('3'):
                state["track_mode"].value = TRACK_YELLOW
                print("Track mode: YELLOW")
            elif key == ord('4'):
                state["track_mode"].value = TRACK_RED_YELLOW
                print("Track mode: RED+YELLOW")

    except KeyboardInterrupt:
        print("\nInterrupted.")
    finally:
        shutdown()


if __name__ == "__main__":
    main()
